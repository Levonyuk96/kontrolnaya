/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/Worklist",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/Object",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/NotFound",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/Browser",
	"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "ControlTaskLevonyuk.ControlTaskLevonyuk.view."
	});

	sap.ui.require([
		"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/WorklistJourney",
		"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/ObjectJourney",
		"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/NavigationJourney",
		"ControlTaskLevonyuk/ControlTaskLevonyuk/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});